/****************************************************************************
** ui.h extension file, included from the uic-generated form implementation.
**
** If you want to add, delete, or rename functions or slots, use
** Qt Designer to update this file, preserving your code.
**
** You should not define a constructor or destructor in this file.
** Instead, write your code in functions called init() and destroy().
** These will automatically be called by the form's constructor and
** destructor.
*****************************************************************************/



void main_window::slot_wep_capture_req()
{

}


void main_window::slot_crack_wpa_aircrack()
{

}


void main_window::slot_crack_wpa_pyrit()
{

}






void main_window::slot_mac_restore()
{

}


void main_window::slot_monitor_on()
{

}


void main_window::slot_net_map_on()
{

}


void main_window::slot_wep_arp_inj_cfrag()
{

}


void main_window::slot_wep_arp_inj_chop()
{

}


void main_window::slot_wep_arp_inj_frag()
{

}


void main_window::slot_wep_assoc_fake_auth_cfrag()
{

}


void main_window::slot_wep_assoc_fake_auth_frag()
{

}


void main_window::slot_wep_assoc_fake_auth_rep()
{

}


void main_window::slot_wep_assoc_fake_auth_req()
{

}


void main_window::slot_wep_create_arp_cfrag()
{

}


void main_window::slot_wep_create_arp_chop()
{

}


void main_window::slot_wep_create_arp_frag()
{

}


void main_window::slot_wep_fake_auth_chop()
{

}


void main_window::slot_wep_start_chop()
{

}


void main_window::slot_wep_start_frag()
{

}


void main_window::slot_wep_start_rep()
{

}







void main_window::slot_wep_test_inj()
{

}


void main_window::slot_wpa_deauth_hand()
{

}


void main_window::slot_wpa_start_sniff_hand()
{

}


void main_window::slot_wpa_test_inj()
{

}


void main_window::slot_crack_wep_aircrack()
{

}


void Main_window::slot_crack_wpa_rainbow_tables()
{

}


void Main_window::slot_wep_start_hirte_adhoc()
{

}


void Main_window::slot_wep_start_hirte_ap()
{

}


void Main_window::slot_wep_start_latte()
{

}





void Main_window::slot_mac_change()
{

}


void Main_window::slot_gath_int()
{

}





void Main_window::slot_save_ap_name()
{

}


void Main_window::slot_save_mon()
{

}


void Main_window::slot_save_mon_mac()
{

}


void Main_window::slot_line_crack_wep_log()
{

}


void Main_window::slot_line_crack_wpa_dictionary()
{

}


void Main_window::slot_line_crack_wpa_dictionary_pyrit()
{

}


void Main_window::slot_line_crack_wpa_log_pyrit()
{

}


void Main_window::slot_line_crack_wpa_rainbow_tables_file()
{

}


void Main_window::slot_line_gath_logs()
{

}


void Main_window::slot_line_mac_change_int()
{

}


void Main_window::slot_line_mac_change_mac()
{

}


void Main_window::slot_line_wep_mac_cfrag()
{

}


void Main_window::slot_line_wpa_mac_hand()
{

}


void Main_window::slot_spin_wep_wired_req()
{

}


void Main_window::slot_spin_wep_wireless_req()
{

}


void Main_window::slot_line_wpa_deauth_hand()
{

}


void Main_window::slot_start_sniffing()
{

}


void Main_window::slot_autoload_ap_info()
{

}


void Main_window::slot_gath_clean()
{

}


void Main_window::slot_enable_ip_forward()
{

}


void Main_window::slot_fake_ap_start()
{

}


void Main_window::slot_save_ap_mac()
{

}


void Main_window::slot_save_ap_chan()
{

}


void Main_window::slot_reload_interfaces()
{

}


void Main_window::slot_autoload_victim_clients()
{

}




void Main_window::slot_rescan_networks()
{

}


void Main_window::slot_interface_selected()
{

}


void Main_window::slot_network_selected()
{

}


void Main_window::slot_disable_ip_forward()
{

}


void Main_window::slot_random_mac()
{

}


void Main_window::slot_line_database()
{

}


void Main_window::slot_database_delete()
{

}


void Main_window::slot_database_reload()
{

}


void Main_window::slot_database_save()
{

}


void Main_window::slot_database_add()
{

}


void Main_window::slot_database_changed()
{

}
