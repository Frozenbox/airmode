airmode
=======

Welcome to AirMode
Do you remember Gerix Wifi Cracker? We decided to fork and resume it in order
to continue providing this fantastic software to everyone.
AirMode is a GUI that can help you to use the Aircrack framework.

Frozenbox Network (www.frozenbox.org)
Parrot Security OS (www.parrotsec.org)
The tool is under GPL 2 License. 
enJoy! 


AirMode Developers
==================


Lisetta "Sheireen" Ferrero
sheireen@frozenbox.org
www.frozenbox.org

Lorenzo "EclipseSpark" Faletra
eclipse@frozenbox.org
www.frozenbox.org




Original Gerix Developers
=========================


Emanuele Gentili
emgent@backtrack-linux.org
Gerix.IT CSO and Partner
http://www.gerix.it

Emanuele Acri
crossbower@backtrack-linux.org
Gerix.IT Penetration Tester
http://www.backtrack.it/~crossbower/
